
============== 1. Import dummy data ===============

Dummy data, file /demo_content/dummy_data.xml, includes all grey images generated from our demo site. It's optimized ( less than 500Kb ) to avoid interruption and error when import to your site. If you still have problem with importing, please try import separated files.


============ 2. Import separated data =============


If you have problem on importing our dummy data, please try import seperated files inside /demo_content/separated_dummy_data folder. Those files include Agents, Properties, Pages, Post + Menu and Attachment. If you import all these files you'll have the same data as with full version.


========== 3. Import Customizer settings ==========


File /demo_content/citilights-demo-settings.json includes Customizer settings on our demo, you can import it by Go to Customizer - Import/Export settings then Upload this file to your site.


================ 4. Basic settings ================


If you're new to WordPress, you'll probably see that your site after import data is completely different from our demo. It's because some basic settings is needed on WordPress site. If you know what the problem is and how to fix it, please skip this section.

1. First, you'll have to set the home page. Please go to Reading setting: Settings -> Reading then choose a Static page for Front page displays. After that, select one of the three home page as your Front page.
You can see more detail at: http://codex.wordpress.org/Creating_a_Static_Front_Page

2. Second, you should assign a menu to your site. Please go to Appearance -> Menus then find Menu Settings -> Theme locations at the bottom. Check the Primary Menu then save it. This action will assign the menu “Main Menu” to the location Primary ( the main menu ) on our theme.
You can see more detail at: http://codex.wordpress.org/Appearance_Menus_Screen

3. Lastly, you should change the Permalink. Please go to Permalinks setting: Settings -> Permalinks then change the Common settings to Post name
You can see more detail at: http://codex.wordpress.org/Using_Permalinks

After doing these steps, your site'll look like our demo, then you can process to build your content.


============== 5. Build your content ==============


1. First, you should check the settings of our theme it includes:
The settings for Agent & Membership: Agents & Membership -> Settings
The settings for Properties: Properties -> Settings
The settings for payment if you use payment on your site: Payment -> Payment Settings

2, Build your content, you can now start adding your Agents and Properties.
Please see our document for more detail: http://docs.nootheme.com/wordpress/citilights/
