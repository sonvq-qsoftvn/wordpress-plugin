=== Tickera Check-in Notifications ===
Contributors: tickera
Requires at least: 4.1
Tested up to: 4.4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Check-in Notifications makes it easy to send emails to guests straight away after the check-in and ensure that your event goes smoothly.

== Description ==

Check-in Notifications makes it easy to send emails to guests straight away after the check-in and ensure that your event goes smoothly.
Inform your attendees about event details (event schedule, map, etc.), let the parents know about their kids arrival to the event or just say hello to your guests.

== Changelog ==

= 1.1.2 - 04/APR/2016 =
- Added plugin updater support for new licensing server

= 1.1.1.1 - 23/NOV/2015 =
- Added automatic updater

= 1.1.1 - 02/NOV/2015 =
- Added additional hooks for developers
- Fixed issues with placeholders

= 1.1 - 02/NOV/2015 =
- Fixed issue with erasing all other options
- Added two more options

= 1.0 - 30/JUN/2015 =
- First Release

