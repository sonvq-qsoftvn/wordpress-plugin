=== Tickera Check-in App Translation ===
Contributors: tickera
Requires at least: 4.1
Tested up to: 4.4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Check-in App Translation allows you to translate iOS and Android check-in application.

== Description ==

Check-in App Translation allows you to translate iOS and Android check-in application.
Just translate the strings via Check-in App Translation add-on, sign into your mobile app and that's it - your Check-in App will be translated.

== Changelog ==

= 1.0.4 - 04/APR/2016 =
- Added plugin updater support for new licensing server

= 1.0.3 - 09/MAR/2015 =
- Added additional strings for translation

= 1.0.2 - 01/MAR/2015 =
- Added additional strings for translation

= 1.0.1 - 23/NOV/2015 =
- Added automatic updater


