=== Tickera - Custom Ticket Template Fonts ===
Contributors: tickera
Requires at least: 4.1
Tested up to: 4.4.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This add-on helps you making more personal, more beautiful ticket templates. Get rid of the boring standard fonts and use any font you like.

== Description ==

This add-on helps you making more personal, more beautiful ticket templates. Get rid of the boring standard fonts and use any font you like. Using the add-on is as simple as just uploading your font and selecting it from the dropdown menu. You can upload as many fonts as you like and use them for different ticket templates.

== Changelog ==

= 1.0.1 - 04/APR/2016 =
- Added plugin updater support for new licensing server

= 1.0.0.1 - 23/NOV/2015 =
- Added automatic updater

= 1.0 - 29/OCT/2015 =
- First Release

